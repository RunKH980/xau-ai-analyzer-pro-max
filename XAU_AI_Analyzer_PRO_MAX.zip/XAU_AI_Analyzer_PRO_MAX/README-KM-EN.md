# XAU AI Analyzer PRO MAX — Full project

## Features
- Live/near-live gold spot price and OHLC candles through Twelve Data.
- H1 + M15 + M5 trend alignment.
- BUY / SELL / WAIT rule-based signal with Entry, SL, TP1/TP2/TP3.
- ICT/SMC observations: BOS, liquidity sweep, 3-candle FVG, possible OB and possible IDM.
- Optional AI explanation using OpenAI Responses API.
- Telegram bot alerts for newly detected BUY/SELL signal.
- M5 historical backtest with total trades, wins, losses and win rate.
- Responsive mobile-first dashboard.

## Important symbol detail
Default provider symbol is `XAU/USD` (spot gold quoted in USD). The label `XAUUSDT` is not a universally supported spot symbol; do not assume a crypto exchange has an XAUUSDT market. If your data provider supports a different symbol, set `TWELVE_DATA_SYMBOL` accordingly. This app's default is XAU/USD.

## Requirements
- Node.js 20+ recommended
- Twelve Data API key
- Optional OpenAI API key (for AI explanation only)
- Optional Telegram Bot Token and Chat ID

API data availability, delay, credits, and historical depth depend on your Twelve Data plan. Free access may not include all real-time commodity feeds.

## Run locally
1. Extract the ZIP.
2. Install Node.js 20+.
3. Open terminal inside this project folder.
4. Run `npm install`.
5. Copy `.env.example` to `.env`.
6. Put your API keys in `.env`.
7. Run `npm start`.
8. Open `http://localhost:3000`.

## Deploy online
Deploy as a Node.js web service (not static-only hosting). Set environment variables in hosting dashboard:
- `TWELVE_DATA_API_KEY`
- `TWELVE_DATA_SYMBOL` (default `XAU/USD`)
- `OPENAI_API_KEY` (optional)
- `OPENAI_MODEL` (optional; default `gpt-4.1-mini`)
- `TELEGRAM_BOT_TOKEN` (optional)
- `TELEGRAM_CHAT_ID` (optional)
- `POLL_INTERVAL_MS` (optional; minimum 60000)
- `PORT` (provided by many hosts)

Do not upload `.env` or expose API keys in frontend JavaScript or public Git repositories.

## Telegram setup
1. In Telegram, open the official `@BotFather`, create a bot, and copy its token.
2. Open your new bot and press Start.
3. Obtain your private chat ID (for example, use a trusted getUpdates method after sending the bot a message).
4. Set `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` on the server.
5. Restart the server and click “Test Telegram Connection”.
6. The server checks the signal periodically and sends a message only when a new BUY/SELL signal candle is detected.

## Backtest methodology and limitations
- Uses fetched M5 historical candles and H1/M15 trend context.
- Signal is calculated from candles available at that historical timestamp.
- Entry is next M5 candle open.
- Stop is based on recent swing / ATR; target is TP2 (2R).
- If SL and TP both occur in the same candle, the test assumes SL first (conservative).
- Excludes spread, commission, swap, slippage, broker feed differences, execution latency, and partial fills.
- Results are not a verified strategy edge and must not be interpreted as expected future returns.

## ICT/SMC definitions are approximations
BOS is approximated using a recent rolling high/low break. Liquidity sweep is approximated as a wick through the prior 11-bar range followed by a close back inside. FVG is approximated using a 3-candle gap. OB and IDM are heuristic labels, not institutional order-flow data. Classic V/A, RBS/SBR, QM, OCL are not automatically classified in this first live-data build; they need additional rule definitions and visual validation.

## Risk and safety
- No automatic broker order placement.
- WAIT is used when confluence is insufficient.
- A screenshot or feed can be delayed or different from your broker.
- Test on demo first. Never risk money you cannot afford to lose.
- This project is educational software, not financial advice.
