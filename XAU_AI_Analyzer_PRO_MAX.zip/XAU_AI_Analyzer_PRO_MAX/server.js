import express from "express";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = Number(process.env.PORT || 3000);
const TD_KEY = process.env.TWELVE_DATA_API_KEY;
const SYMBOL = process.env.TWELVE_DATA_SYMBOL || "XAU/USD";
const cache = new Map();
let lastTelegramSignal = "";

const intervals = { M5: "5min", M15: "15min", H1: "1h" };

async function getCandles(tf, outputsize = 300) {
  if (!TD_KEY) throw new Error("សូមកំណត់ TWELVE_DATA_API_KEY ក្នុង .env ជាមុន។");
  const cacheKey = `${tf}-${outputsize}`;
  const cached = cache.get(cacheKey);
  if (cached && Date.now() - cached.at < 30000) return cached.data;

  const url = new URL("https://api.twelvedata.com/time_series");
  url.search = new URLSearchParams({
    symbol: SYMBOL, interval: intervals[tf], outputsize: String(outputsize),
    order: "ASC", timezone: "UTC", apikey: TD_KEY
  }).toString();
  const response = await fetch(url);
  const data = await response.json();
  if (!response.ok || data.status === "error" || !Array.isArray(data.values)) {
    throw new Error(data.message || data.code || "មិនអាចទាញ Candle Data ពី Twelve Data បាន។ ពិនិត្យ Symbol/API plan/key។");
  }
  const candles = data.values.map(v => ({
    time: v.datetime,
    open: +v.open, high: +v.high, low: +v.low, close: +v.close,
    volume: +(v.volume || 0)
  })).filter(c => [c.open,c.high,c.low,c.close].every(Number.isFinite));
  if (candles.length < 60) throw new Error(`ទិន្នន័យ ${tf} មានតិចពេក (${candles.length} candles)។`);
  cache.set(cacheKey, { at: Date.now(), data: candles });
  return candles;
}

const mean = a => a.reduce((s,v)=>s+v,0)/Math.max(1,a.length);
function ema(values, period) {
  const out = Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2/(period+1);
  let prev = mean(values.slice(0,period));
  out[period-1] = prev;
  for(let i=period;i<values.length;i++){ prev = values[i]*k + prev*(1-k); out[i]=prev; }
  return out;
}
function rsi(values, period=14) {
  const out = Array(values.length).fill(null);
  if(values.length<=period) return out;
  let gain=0, loss=0;
  for(let i=1;i<=period;i++){const d=values[i]-values[i-1];gain+=Math.max(d,0);loss+=Math.max(-d,0);}
  let ag=gain/period, al=loss/period;
  out[period]=al===0?100:100-100/(1+ag/al);
  for(let i=period+1;i<values.length;i++){
    const d=values[i]-values[i-1]; ag=(ag*(period-1)+Math.max(d,0))/period; al=(al*(period-1)+Math.max(-d,0))/period;
    out[i]=al===0?100:100-100/(1+ag/al);
  }
  return out;
}
function atr(c, period=14) {
  const tr=c.map((x,i)=>i===0?x.high-x.low:Math.max(x.high-x.low,Math.abs(x.high-c[i-1].close),Math.abs(x.low-c[i-1].close)));
  const out=Array(c.length).fill(null);
  if(c.length<period) return out;
  let v=mean(tr.slice(0,period)); out[period-1]=v;
  for(let i=period;i<c.length;i++){v=(v*(period-1)+tr[i])/period;out[i]=v;}
  return out;
}
function analyzeSeries(c) {
  const close=c.map(x=>x.close), e20=ema(close,20), e50=ema(close,50), rr=rsi(close), aa=atr(c);
  const i=c.length-1, p=c[i], prev=c[i-1];
  const from=Math.max(0,i-12), recent=c.slice(from,i);
  const swingHigh=Math.max(...recent.map(x=>x.high));
  const swingLow=Math.min(...recent.map(x=>x.low));
  const bullBreak=p.close>swingHigh, bearBreak=p.close<swingLow;
  const bullFvg=i>=2 && c[i-2].high<p.low;
  const bearFvg=i>=2 && c[i-2].low>p.high;
  const bullEngulf=p.close>p.open && prev.close<prev.open && p.close>prev.open && p.open<prev.close;
  const bearEngulf=p.close<p.open && prev.close>prev.open && p.close<prev.open && p.open>prev.close;
  let bias="NEUTRAL";
  if(e20[i] && e50[i] && p.close>e20[i] && e20[i]>e50[i]) bias="BULLISH";
  if(e20[i] && e50[i] && p.close<e20[i] && e20[i]<e50[i]) bias="BEARISH";
  return {
    timeframe:null, price:p.close, time:p.time, ema20:e20[i], ema50:e50[i],
    rsi:rr[i], atr:aa[i], bias, bullBreak, bearBreak, bullFvg, bearFvg,
    bullEngulf, bearEngulf, swingHigh, swingLow,
    candle:p
  };
}
function buildSignal(h1,m15,m5) {
  const bullMTF=h1.bias==="BULLISH" && m15.bias==="BULLISH";
  const bearMTF=h1.bias==="BEARISH" && m15.bias==="BEARISH";
  const buyTrigger=m5.bullBreak || m5.bullEngulf || m5.bullFvg;
  const sellTrigger=m5.bearBreak || m5.bearEngulf || m5.bearFvg;
  let signal="WAIT", reasons=[];
  if(bullMTF && buyTrigger && m5.rsi>=50 && m5.rsi<=75){signal="BUY";reasons=["H1 និង M15 មាន Bias ឡើង","M5 មាន Trigger ឡើង","RSI M5 គាំទ្រទិស BUY"];}
  else if(bearMTF && sellTrigger && m5.rsi<=50 && m5.rsi>=25){signal="SELL";reasons=["H1 និង M15 មាន Bias ចុះ","M5 មាន Trigger ចុះ","RSI M5 គាំទ្រទិស SELL"];}
  else {
    reasons.push("មិនទាន់មានការបញ្ជាក់គ្រប់គ្រាន់ពី H1 + M15 + M5");
    if(h1.bias!==m15.bias) reasons.push("Trend H1 និង M15 មិនស្របគ្នា");
  }
  const entry=m5.price, a=m5.atr || 0;
  const slDist=Math.max(a*1.5, entry*0.0008);
  let plan={entry:null,sl:null,tp1:null,tp2:null,tp3:null,rr:"1:1 / 1:2 / 1:3"};
  if(signal==="BUY") plan={entry,sl:entry-slDist,tp1:entry+slDist,tp2:entry+2*slDist,tp3:entry+3*slDist,rr:"1:1 / 1:2 / 1:3"};
  if(signal==="SELL") plan={entry,sl:entry+slDist,tp1:entry-slDist,tp2:entry-2*slDist,tp3:entry-3*slDist,rr:"1:1 / 1:2 / 1:3"};
  return {
    signal, reasons, plan, symbol:SYMBOL, updatedAt:new Date().toISOString(),
    timeframes:{H1:{bias:h1.bias,rsi:h1.rsi,price:h1.price,time:h1.time},M15:{bias:m15.bias,rsi:m15.rsi,price:m15.price,time:m15.time},M5:{bias:m5.bias,rsi:m5.rsi,price:m5.price,time:m5.time}},
    concepts:{BOS:m5.bullBreak?"Bullish":m5.bearBreak?"Bearish":"Not confirmed",FVG:m5.bullFvg?"Bullish":m5.bearFvg?"Bearish":"Not detected",OB:"Approximation: last opposite candle before impulse is not fully validated",IDM:"Liquidity inducement needs manual swing confirmation",QM:"Not automatically confirmed",RBS_SBR:"Not automatically confirmed",OCL:"Current candle open/close reference"},
    metrics:{rsi:m5.rsi,atr:m5.atr,ema20:m5.ema20,ema50:m5.ema50,confidence:signal==="WAIT"?"Low":"Medium"},
    note:"នេះជាសញ្ញាតាម Rule Engine មិនមែន AI ដែលធានាឈ្នះទេ។ តម្លៃ Entry/SL/TP ជាគម្រោងគណនាពី ATR និងត្រូវផ្ទៀងផ្ទាត់ spread/execution របស់ broker។"
  };
}
function backtest(c) {
  const closes=c.map(x=>x.close), e20=ema(closes,20), e50=ema(closes,50), rr=rsi(closes), aa=atr(c);
  let wins=0, losses=0, trades=0, netR=0, equity=0, peak=0, maxDD=0;
  const sample=[];
  for(let i=60;i<c.length-2;i++){
    const bull=e20[i]>e50[i] && c[i].close>e20[i] && rr[i]>=52;
    const bear=e20[i]<e50[i] && c[i].close<e20[i] && rr[i]<=48;
    if(!bull && !bear) continue;
    const dir=bull?1:-1, entry=c[i].close, dist=Math.max((aa[i]||0)*1.5,entry*0.0008);
    const sl=entry-dir*dist, tp=entry+dir*dist*2;
    let result=null, exit=null;
    for(let j=i+1;j<Math.min(i+25,c.length);j++){
      const hitSL=dir===1?c[j].low<=sl:c[j].high>=sl;
      const hitTP=dir===1?c[j].high>=tp:c[j].low<=tp;
      if(hitSL && hitTP){result=-1;exit=sl;break;} // conservative: assume SL first
      if(hitSL){result=-1;exit=sl;break;}
      if(hitTP){result=2;exit=tp;break;}
    }
    if(result===null) continue;
    trades++; netR+=result; equity+=result; peak=Math.max(peak,equity); maxDD=Math.max(maxDD,peak-equity);
    if(result>0)wins++;else losses++;
    if(sample.length<8)sample.push({time:c[i].time,side:dir===1?"BUY":"SELL",entry,exit,r:result});
  }
  return {trades,wins,losses,winRate:trades?+(wins/trades*100).toFixed(1):0,netR:+netR.toFixed(2),maxDrawdownR:+maxDD.toFixed(2),sample,method:"M5 EMA20/EMA50 + RSI filter; Entry at candle close; SL=1.5 ATR; TP=2R; max hold=24 candles; same-candle SL/TP assumes SL first; no spread/commission/slippage."};
}
async function sendTelegram(text) {
  const token=process.env.TELEGRAM_BOT_TOKEN, chat=process.env.TELEGRAM_CHAT_ID;
  if(!token || !chat) return {sent:false,reason:"Telegram មិនទាន់បានកំណត់"};
  const r=await fetch(`https://api.telegram.org/bot${token}/sendMessage`,{
    method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({chat_id:chat,text,disable_web_page_preview:true})
  });
  const j=await r.json();
  if(!r.ok || !j.ok) throw new Error(j.description||"Telegram send failed");
  return {sent:true};
}

app.get("/api/dashboard", async (_req,res)=>{
  try {
    const [h1c,m15c,m5c]=await Promise.all([getCandles("H1"),getCandles("M15"),getCandles("M5")]);
    const h1=analyzeSeries(h1c),m15=analyzeSeries(m15c),m5=analyzeSeries(m5c);
    const signal=buildSignal(h1,m15,m5);
    res.json({ok:true,signal,backtest:backtest(m5c),candles:m5c.slice(-80),provider:"Twelve Data",dataDelayNote:"Feed delay and availability depend on your Twelve Data plan."});
  } catch(e){res.status(502).json({ok:false,error:e.message});}
});
app.post("/api/telegram-test",async(_req,res)=>{
  try{const r=await sendTelegram("✅ XAU AI Analyzer PRO MAX: Telegram connection test.");res.json(r);}
  catch(e){res.status(400).json({error:e.message});}
});
app.post("/api/telegram-alert",async(req,res)=>{
  try{
    const s=req.body?.signal;
    if(!s || !["BUY","SELL"].includes(s.signal)) return res.status(400).json({error:"No BUY/SELL signal."});
    const key=`${s.signal}-${s.timeframes?.M5?.time}-${s.plan?.entry}`;
    if(key===lastTelegramSignal)return res.json({sent:false,reason:"Signal នេះបានផ្ញើរួចហើយ"});
    const p=s.plan;
    await sendTelegram(`📊 XAU AI ANALYZER\nSignal: ${s.signal}\nSymbol: ${s.symbol}\nEntry: ${p.entry?.toFixed(2)}\nSL: ${p.sl?.toFixed(2)}\nTP1: ${p.tp1?.toFixed(2)}\nTP2: ${p.tp2?.toFixed(2)}\nTP3: ${p.tp3?.toFixed(2)}\nTime: ${s.timeframes.M5.time}\nReminder: verify spread and risk before trading.`);
    lastTelegramSignal=key;res.json({sent:true});
  }catch(e){res.status(400).json({error:e.message});}
});
app.get("/api/health",(_req,res)=>res.json({ok:true,provider:"Twelve Data",symbol:SYMBOL}));
app.listen(PORT,()=>console.log(`XAU AI Analyzer PRO MAX: http://localhost:${PORT}`));
