# XAU AI Analyzer PRO MAX — Khmer Setup

## Features
- Latest available XAU/USD candles from Twelve Data
- H1 + M15 trend alignment, M5 trigger
- BUY / SELL / WAIT
- ATR-based Entry / SL / TP1 / TP2 / TP3 plan
- Historical M5 backtest and Win/Loss statistics
- Optional Telegram signal alerts
- Responsive mobile dashboard

## Important limitations
- This is a deterministic, rule-based technical analysis engine (AI-style dashboard), not a machine-learning model and not a broker execution bot.
- Twelve Data's feed may be delayed or restricted by your plan. The app labels it as latest provider data, not guaranteed broker-live tick data.
- ICT terms such as OB, IDM, QM, RBS/SBR and OCL are not universally standardized. This MVP reports limited pattern proxies and marks concepts that cannot be reliably automated as unconfirmed.
- Backtest uses an explicitly described EMA20/EMA50 + RSI M5 rule set. It excludes spread, fees, slippage, latency and partial fills; historical results do not predict future performance.
- Never connect this to live order execution without independent testing and strict risk controls.

## Requirements
- Node.js 20+
- Twelve Data API key
- Optional Telegram bot token + chat ID

## Run locally
1. Extract this ZIP.
2. Install Node.js on a computer/server.
3. Open a terminal inside this folder.
4. Run `npm install`.
5. Copy `.env.example` to `.env`.
6. Add your Twelve Data API key to `TWELVE_DATA_API_KEY`.
7. Keep `TWELVE_DATA_SYMBOL=XAU/USD` for spot gold. This provider's instrument symbol is XAU/USD, not necessarily your broker's XAUUSDT CFD.
8. Run `npm start`.
9. Open `http://localhost:3000`.

## Telegram setup (optional)
1. In Telegram, talk to BotFather and create a bot.
2. Copy the bot token into `TELEGRAM_BOT_TOKEN`.
3. Send `/start` to your bot.
4. Obtain your chat ID using a trusted Telegram bot/API method, then set `TELEGRAM_CHAT_ID`.
5. Restart the server and press "Test Telegram".
6. Do not publish the token or share your `.env` file.

## Deploy online
Deploy to a Node.js host that supports Express and outbound HTTPS. Set the environment variables in the host dashboard. Do not put keys in `public/index.html`, source control, or a public client app. Enable authentication/rate limiting before sharing publicly. Use HTTPS.

## Data provider
Twelve Data time_series endpoint:
`https://api.twelvedata.com/time_series`
The app requests 5min, 15min, and 1h candles, caches each request for 30 seconds, and uses UTC timestamps.

## Strategy details
Signal:
- H1 and M15 must have matching EMA20/EMA50 trend.
- M5 must show a recent break of a 12-bar local range, a simple engulfing candle, or a 3-candle FVG proxy.
- M5 RSI must agree with direction.
- Otherwise WAIT.

Risk plan:
- Entry = latest M5 close.
- SL distance = max(1.5 × M5 ATR(14), 0.08% of price).
- TP1 = 1R, TP2 = 2R, TP3 = 3R.

Backtest:
- M5 EMA20/EMA50 + RSI(14) filter (BUY RSI >= 52; SELL RSI <= 48).
- Entry at signal candle close, SL = 1.5 ATR, TP = 2R.
- Maximum holding period = 24 candles.
- If SL and TP occur in same candle, assume SL first (conservative).
- Only completed trades are counted.

## Troubleshooting
- `Invalid API key` / quota errors: verify your Twelve Data key, credits, plan limits and symbol availability.
- `No data`: confirm `TWELVE_DATA_SYMBOL=XAU/USD`.
- Telegram test fails: check bot token, chat ID, and send `/start` to the bot first.
- If using mobile only: deploy on a Node.js hosting service from a browser or use a trusted online development environment. The phone itself does not run this server just by opening the HTML file.
